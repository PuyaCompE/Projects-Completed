from flask import Flask, render_template, request, make_response
from flask_compress import Compress

#<input type="hidden" name="csrf_token" value="bb63e4ba67e24dab81ed425c5a95b7a2">

app = Flask(__name__)

compression = 1

if compression:
    app.config["COMPRESS_ALGORITHM"] = 'gzip'
    compress = Compress()
    compress.init_app(app)

@app.get('/')
def home():
    # set a CSRF token manually and set it as a cookie
    csrf_token = 'yummy_lil_token'
    response = make_response(render_template('index.html'))
    response.set_cookie('csrf_token', csrf_token)
    return response

@app.get('/secret')
def secret():
    print(request.query_string)
    print(request.args.get('request_token'))

    #t = "<input type='hidden' request_token='{}'>".format(request.args.get('request_token'))

    response = make_response(render_template('secretv2.html', target_attempt = request.args.get('request_token')))
    
    return response

@app.post('/submit')
def submit():
    # check if the CSRF token in the request matches the one in the cookie
    print(request.cookies.get('csrf_token'))
    if request.cookies.get('csrf_token') != 'yummy_lil_token': #'bb63e4ba67e24dab81ed425c5a95b7a2':#'my_csrf_token':
        return 'Invalid CSRF token'

    # process the form data
    name = request.form.get('name')
    email = request.form.get('email')

    # do something with the data (e.g. save it to a database)

    return '<p>Form submitted successfully</p><p>SUPER SECRET PAGE!!!!</p>'

if __name__ == '__main__':
    app.run(debug=True)