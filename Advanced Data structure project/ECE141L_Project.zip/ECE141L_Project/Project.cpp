//PUYA FARD_ECE141L_Project
#include <iostream>
#include <vector>
#include <chrono>
#include<algorithm>
#include <unistd.h>

using namespace std::chrono;
using namespace std;

void bubbleSort(vector<int>& arr) {
    int n = arr.size();
    for(int i = 0; i < n - 1; i++) {
        for(int j = 0; j < n - i - 1; j++) {
            if(arr[j] > arr[j + 1]) {
                // Swap arr[j] and arr[j+1]
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void Opt_bubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped;
    for(int i = 0; i < n - 1; i++) {
        swapped = false;
        for(int j = 0; j < n - i - 1; j++) {
            if(arr[j] > arr[j + 1]) {
                // Swap arr[j] and arr[j+1]
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swapped = true;
            }
        }
        // If no two elements were swapped by inner loop, break
        if(!swapped) {
            break;
        }
    }
}
void Rec_bubbleSort(vector<int>& arr, int n) {
    if(n == 1) {
        return;
    }
    for(int i = 0; i < n - 1; i++) {
        if(arr[i] > arr[i + 1]) {
            // Swap arr[i] and arr[i+1]
            int temp = arr[i];
            arr[i] = arr[i + 1];
            arr[i + 1] = temp;
        }
    }
    Rec_bubbleSort(arr, n - 1);
}

void cocktailSort(vector<int>& arr) {
    int n = arr.size();
    bool swapped = true;
    int start = 0;
    int end = n - 1;
    while(swapped) {
        swapped = false;
        for(int i = start; i < end; i++) {
            if(arr[i] > arr[i + 1]) {
                // Swap arr[i] and arr[i+1]
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                swapped = true;
            }
        }
        if(!swapped) {
            break;
        }
        swapped = false;
        end--;
        for(int i = end - 1; i >= start; i--) {
            if(arr[i] > arr[i + 1]) {
                // Swap arr[i] and arr[i+1]
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                swapped = true;
            }
        }
        start++;
    }
}

void combSort(vector<int>& arr) {
    int n = arr.size();
    int gap = n;
    bool swapped = true;
    while(gap > 1 || swapped) {
        gap = max(1, int(gap / 1.3));
        swapped = false;
        for(int i = 0; i + gap < n; i++) {
            if(arr[i] > arr[i + gap]) {
                // Swap arr[i] and arr[i+gap]
                int temp = arr[i];
                arr[i] = arr[i + gap];
                arr[i + gap] = temp;
                swapped = true;
            }
        }
    }
}

int main()
{
//Ask user for pick an algorithm to continue, or run all.
int choice=0;
cout << "What sorting algorithm would you like to pick?\n1: Standard Bubble sort.\n2: Optimized Bubble sort.\n3: Recursive Bubble sort. \n4: Cocktail Shaker sort. \n5: Comb sort. \n6: Run all."<<endl;
cout<<"option = #";
cin>>choice;

switch (choice){

case 1:{
int case1=0;
cout<<endl;
cout<<"For standard Bubble sort algorithm, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
   }

   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
    int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_SBS = chrono::steady_clock::now(); // Clock Start
    bubbleSort(arr);
    auto End_SBS = chrono::steady_clock::now(); // Clock End
    auto dur_SBS = duration_cast<microseconds>(End_SBS - start_SBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Standard Bubble Sort: " << dur_SBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
            cin >> arr[i];
    }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_SBS = chrono::steady_clock::now(); // Clock Start
    bubbleSort(arr);
    auto End_SBS = chrono::steady_clock::now(); // Clock End
    auto dur_SBS = duration_cast<microseconds>(End_SBS - start_SBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Standard Bubble Sort: " << dur_SBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
default:
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}
}
break;
case 2:{
int case1=0;
cout<<endl;
cout<<"For Optimized bubble sort algorithm, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_OBS = chrono::steady_clock::now(); // Clock Start
    Opt_bubbleSort(arr);
    auto End_OBS = chrono::steady_clock::now(); // Clock End
    auto dur_OBS = duration_cast<microseconds>(End_OBS - start_OBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Optimized Bubble Sort: " << dur_OBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
            cin >> arr[i];
    }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_OBS = chrono::steady_clock::now(); // Clock Start
    Opt_bubbleSort(arr);
    auto End_OBS = chrono::steady_clock::now(); // Clock End
    auto dur_OBS = duration_cast<microseconds>(End_OBS - start_OBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Optimized Bubble Sort: " << dur_OBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
default:
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}

}
break;
case 3:{
int case1=0;
cout<<endl;
cout<<"For Recursive Bubble sort algorithm, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_RBS = chrono::steady_clock::now(); // Clock Start
    Rec_bubbleSort(arr, n);
    auto End_RBS = chrono::steady_clock::now(); // Clock End
    auto dur_RBS = duration_cast<microseconds>(End_RBS - start_RBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Recursive Bubble Sort: " << dur_RBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
            cin >> arr[i];
    }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_RBS = chrono::steady_clock::now(); // Clock Start
    Rec_bubbleSort(arr, n);
    auto End_RBS = chrono::steady_clock::now(); // Clock End
    auto dur_RBS = duration_cast<microseconds>(End_RBS - start_RBS);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Recursive Bubble Sort: " << dur_RBS.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
default:
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}
}
break;
case 4:{
int case1=0;
cout<<endl;
cout<<"For Cocktail Shaker sort algorithm, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CST = chrono::steady_clock::now(); // Clock Start
    cocktailSort(arr);
    auto End_CST = chrono::steady_clock::now(); // Clock End
    auto dur_CST = duration_cast<microseconds>(End_CST - start_CST);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Cocktail Shaker Sort: " << dur_CST.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
            cin >> arr[i];
    }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CST = chrono::steady_clock::now(); // Clock Start
    cocktailSort(arr);
    auto End_CST = chrono::steady_clock::now(); // Clock End
    auto dur_CST = duration_cast<microseconds>(End_CST - start_CST);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Cocktail Shaker Sort: " << dur_CST.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
default:
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}
}
break;
case 5:{
int case1=0;
cout<<endl;
cout<<"For Comb sort algorithm, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CBM = chrono::steady_clock::now(); // Clock Start
    combSort(arr);
    auto End_CBM = chrono::steady_clock::now(); // Clock End
    auto dur_CBM = duration_cast<microseconds>(End_CBM - start_CBM);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Comb sort: " << dur_CBM.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
            cin >> arr[i];
    }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array is:\n";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CBM = chrono::steady_clock::now(); // Clock Start
    combSort(arr);
    auto End_CBM = chrono::steady_clock::now(); // Clock End
    auto dur_CBM = duration_cast<microseconds>(End_CBM - start_CBM);
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Comb sort: " << dur_CBM.count() << " microseconds" << endl;
    for(int i = 0; i < n; i++){
        arr[i];
    }
    }
}
break;
default:
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}
}
break;
case 6:{
int case1=0;
cout<<endl;
cout<<"For running all algorithms, do you want to generate random numbers, or fill your own n size array?\n1:Generate random size n.\n2:Manual entry size n."<<endl;
cout<<"option = #";
cin>>case1;
switch(case1){
case 1:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    vector<int> brr(n);

    // Generate random numbers within the array for the corresponding size
    for(int i = 0; i < n; i++){
        arr[i] = (rand()%100 +1);
        brr[i] = arr[i];
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array a is:\n";
    for (int i = 0; i < n; i++) {
        cout << brr[i] << " ";
    }
   }
    brr=arr; //back to unsorted array
        int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the standard bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_SBS = chrono::steady_clock::now(); // Clock Start
    bubbleSort(arr);
    auto End_SBS = chrono::steady_clock::now(); // Clock End
    auto dur_SBS = duration_cast<microseconds>(End_SBS - start_SBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the optimized bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_OBS = chrono::steady_clock::now(); // Clock Start
    Opt_bubbleSort(arr);
    auto End_OBS = chrono::steady_clock::now(); // Clock End
    auto dur_OBS = duration_cast<microseconds>(End_OBS - start_OBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the recursive bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_RBS = chrono::steady_clock::now(); // Clock Start
    Rec_bubbleSort(arr, n);
    auto End_RBS = chrono::steady_clock::now(); // Clock End
    auto dur_RBS = duration_cast<microseconds>(End_RBS - start_RBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the cocktail sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CST = chrono::steady_clock::now(); // Clock Start
    cocktailSort(arr);
    auto End_CST = chrono::steady_clock::now(); // Clock End
    auto dur_CST = duration_cast<microseconds>(End_CST - start_CST);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the comb sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CBM = chrono::steady_clock::now(); // Clock Start
    combSort(arr);
    auto End_CBM = chrono::steady_clock::now(); // Clock End
    auto dur_CBM = duration_cast<microseconds>(End_CBM - start_CBM);

    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Standard Bubble sort: " << dur_SBS.count() << " microseconds" << endl;
    cout<< "Time to complete Optimized Bubble sort: " << dur_OBS.count() << " microseconds" << endl;
    cout<< "Time to complete Recursive Bubble sort: " << dur_RBS.count() << " microseconds" << endl;
    cout<< "Time to complete Cocktail Shaker sort: " << dur_CST.count() << " microseconds" << endl;
    cout<< "Time to complete Comb sort: " << dur_CBM.count() << " microseconds" << endl;
    }
}
break;
case 2:{
    // Ask the user for the size of the array
    int n=0; //reset n
    cout << "Enter the size N of the array: ";
    cin >> n;
    vector<int> arr(n);
    vector<int> brr(n);

     cout<<"Fill your array by entering elements one by one:\n";
    for (int i = 0; i < n; i++){  // for loop used to input values in array
        cin >> arr[i];
        brr[i] = arr[i];
   }
   int yesNo=0;
   cout<<"Do you want to print out the unsorted array? 1:Yes, 2:No, ";
   cin>>yesNo;
   if(yesNo==1){
    // Print the unsorted array
    cout << "The unsorted array a is:\n";
    for (int i = 0; i < n; i++) {
        cout << brr[i] << " ";
    }
   }
       int sin;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the standard bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_SBS = chrono::steady_clock::now(); // Clock Start
    bubbleSort(arr);
    auto End_SBS = chrono::steady_clock::now(); // Clock End
    auto dur_SBS = duration_cast<microseconds>(End_SBS - start_SBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the optimized bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_OBS = chrono::steady_clock::now(); // Clock Start
    Opt_bubbleSort(arr);
    auto End_OBS = chrono::steady_clock::now(); // Clock End
    auto dur_OBS = duration_cast<microseconds>(End_OBS - start_OBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the recursive bubble sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_RBS = chrono::steady_clock::now(); // Clock Start
    Rec_bubbleSort(arr, n);
    auto End_RBS = chrono::steady_clock::now(); // Clock End
    auto dur_RBS = duration_cast<microseconds>(End_RBS - start_RBS);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the cocktail sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CST = chrono::steady_clock::now(); // Clock Start
    cocktailSort(arr);
    auto End_CST = chrono::steady_clock::now(); // Clock End
    auto dur_CST = duration_cast<microseconds>(End_CST - start_CST);

    brr=arr; //back to unsorted array
    sin=0;
    cout<<endl<<"Would you prefer to input\n1: unsorted array\n2: sorted array\n3: reverse sorted array\ninto the comb sort algorithm? "<<endl;
    cout<<"option = #";
    cin>>sin;
    if(sin==1){
        cout<<"unsorted array input chosen."<<endl;
    }
    else if(sin==2){
        sort(arr.begin(), arr.end()); // Sort ascending
        cout<<"sorted array input chosen."<<endl;

    }
    else if(sin==3){
            sort(arr.begin(), arr.end(), greater<int>()); // Sort descending
            cout<<"reverse sorted array input chosen."<<endl;
    }
    else
        cout<<"error input, the program will continue with unsorted array as default."<<endl;

    auto start_CBM = chrono::steady_clock::now(); // Clock Start
    combSort(arr);
    auto End_CBM = chrono::steady_clock::now(); // Clock End
    auto dur_CBM = duration_cast<microseconds>(End_CBM - start_CBM);

    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the sorted array? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    // Print the sorted array
    cout << "The sorted array is: "<<endl;
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    }
    yesNo=0;
    cout<<endl;
    cout<<"Do you want to print out the execution time? 1:Yes, 2:No, ";
    cin>>yesNo;
    if(yesNo==1){
    //print the execution time
    cout<<endl;
    cout<< "Time to complete Standard Bubble sort: " << dur_SBS.count() << " microseconds" << endl;
    cout<< "Time to complete Optimized Bubble sort: " << dur_OBS.count() << " microseconds" << endl;
    cout<< "Time to complete Recursive Bubble sort: " << dur_RBS.count() << " microseconds" << endl;
    cout<< "Time to complete Cocktail Shaker sort: " << dur_CST.count() << " microseconds" << endl;
    cout<< "Time to complete Comb sort: " << dur_CBM.count() << " microseconds" << endl;
    }
}

default:{
cout<<"Error entry, please restart"<<endl<<endl;
return main();
}
}
}
default:{
    cout<<"Program ended, restarting";
    sleep(1);
    cout<<"..";
    sleep(1);
    cout<<"..";
    sleep(1);
    cout<<".."<<endl<<endl;

    return main();
}
}
cout<<endl;
cout<<"End of the program"<<endl;
int restart;
cout<<"If you want to end the program type 1, to return back type 2"<<endl;
cin>>restart;
if (restart==1){
    return 0;
}
else
    cout<<endl;
    cout<<"Program restarting";
    sleep(1);
    cout<<"..";
    sleep(1);
    cout<<"..";
    sleep(1);
    cout<<".."<<endl<<endl;
    return main();
}
